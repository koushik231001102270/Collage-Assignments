import './App.css'
import { Content } from './components/Content'

function App() {

  return (
    <>
      <header>
      </header>
      <Content/>
    </>
  )
}

export default App
